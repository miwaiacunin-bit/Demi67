1. Установите Python 3.10+ и: pip install numpy
2. Запустите: python server.py
3. Узнайте IP компьютера (ipconfig / ifconfig). Телефон и ПК в одной Wi-Fi сети.
4. В приложении выберите "Годжо (сервер)", введите IP и порт 5005, включите микрофон.
   Если слышите свой голос без изменений, связь работает.
5. Для настоящего голоса положите модели RVC в models/gojo.pth и models/sukuna.pth
   и подключите их в Converter.convert (см. TODO в server.py). Нужна видеокарта NVIDIA.
