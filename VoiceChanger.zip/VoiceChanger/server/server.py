"""Сервер смены голоса. Запуск: python server.py  (порт 5005)
Телефон шлёт PCM16 16 кГц моно кусками по CHUNK сэмплов, сервер возвращает такой же кусок.
"""
import asyncio
import numpy as np

CHUNK = 4096  # должно совпадать с chunk в ServerEngine.kt
PORT = 5005


class Converter:
    def __init__(self, voice: str):
        self.voice = voice
        # TODO: загрузите RVC-модель из models/{voice}.pth (+ .index), например через пакет rvc-python:
        #   from rvc_python.infer import RVCInference
        #   self.rvc = RVCInference(device="cuda:0"); self.rvc.load_model(f"models/{voice}.pth")
        print(f"[{voice}] готов (сейчас режим проверки: звук возвращается без изменений)")

    def convert(self, pcm: np.ndarray) -> np.ndarray:
        # Здесь вызывается нейросеть: pcm int16 -> int16 того же размера.
        # Пока просто возвращаем звук, чтобы проверить связь с телефоном.
        return pcm


async def handle(reader, writer):
    voice = (await reader.readline()).decode().strip()
    conv = Converter(voice)
    print("подключился", writer.get_extra_info("peername"), voice)
    try:
        while True:
            data = await reader.readexactly(CHUNK * 2)
            out = conv.convert(np.frombuffer(data, dtype=np.int16))
            writer.write(out.astype(np.int16).tobytes())
            await writer.drain()
    except (asyncio.IncompleteReadError, ConnectionError):
        pass
    finally:
        writer.close()
        print("отключился")


class Discovery(asyncio.DatagramProtocol):
    def connection_made(self, transport):
        self.t = transport

    def datagram_received(self, data, addr):
        if data.startswith(b"VC?"):
            self.t.sendto(b"VC!", addr)


def my_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "не удалось определить"


async def main():
    srv = await asyncio.start_server(handle, "0.0.0.0", PORT)
    await asyncio.get_running_loop().create_datagram_endpoint(Discovery, local_addr=("0.0.0.0", 5006))
    print(f"Слушаю порт {PORT}")
    print(f"Ваш IP для приложения: {my_ip()}  (или нажмите 'Найти сервер автоматически')")
    async with srv:
        await srv.serve_forever()

asyncio.run(main())
