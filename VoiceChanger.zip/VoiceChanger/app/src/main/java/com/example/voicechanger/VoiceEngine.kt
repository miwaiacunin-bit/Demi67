package com.example.voicechanger

import android.annotation.SuppressLint
import android.media.*
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

enum class Fx { NONE, ROBOT, HIGH, LOW, ECHO, GOJO, SUKUNA }

/** Простой питч-шифтер: две линии задержки с треугольным кроссфейдом. */
class PitchShifter(private val ratio: Float) {
    private val win = 1024
    private val buf = FloatArray(4096)
    private var w = 0
    private var phase = 0f
    private fun read(d: Float): Float {
        val pos = (w - d + buf.size) % buf.size
        val i = pos.toInt(); val f = pos - i
        return buf[i] * (1 - f) + buf[(i + 1) % buf.size] * f
    }
    fun process(x: Float): Float {
        buf[w] = x
        val d1 = phase
        val d2 = (phase + win / 2f) % win
        val g1 = 1f - abs(2f * d1 / win - 1f)
        val g2 = 1f - abs(2f * d2 / win - 1f)
        val y = read(d1) * g1 + read(d2) * g2
        w = (w + 1) % buf.size
        phase += 1f - ratio
        if (phase >= win) phase -= win
        if (phase < 0) phase += win
        return y
    }
}

class VoiceEngine {
    @Volatile var fx = Fx.NONE
    @Volatile private var running = false
    private var thread: Thread? = null
    private val sr = 44100

    @SuppressLint("MissingPermission")
    fun start(input: AudioDeviceInfo?) {
        if (running) return
        running = true
        thread = Thread {
            val minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minIn)
            if (input != null) rec.preferredDevice = input
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(minOut)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
            val high = PitchShifter(1.5f)
            val low = PitchShifter(0.7f)
            val gojo = PitchShifter(0.9f)
            val suku = PitchShifter(0.68f)
            val echo = FloatArray(sr * 3 / 10); var ei = 0
            var t = 0.0
            val buf = ShortArray(512)
            rec.startRecording(); track.play()
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                for (i in 0 until n) {
                    val x = buf[i] / 32768f
                    val y = when (fx) {
                        Fx.NONE -> x
                        Fx.ROBOT -> { t += 1.0 / sr; x * sin(2 * PI * 60 * t).toFloat() * 1.4f }
                        Fx.HIGH -> high.process(x)
                        Fx.LOW -> low.process(x)
                        Fx.GOJO -> gojo.process(x) * 1.2f
                        Fx.SUKUNA -> { val p = suku.process(x) * 2.5f; val c = Math.tanh(p.toDouble()).toFloat()
                            val d = echo[ei]; echo[ei] = c + d * 0.3f; ei = (ei + 1) % echo.size; c + d * 0.25f }
                        Fx.ECHO -> { val d = echo[ei]; echo[ei] = x + d * 0.4f; ei = (ei + 1) % echo.size; x + d * 0.5f }
                    }
                    buf[i] = (y.coerceIn(-1f, 1f) * 32767).toInt().toShort()
                }
                track.write(buf, 0, n)
            }
            rec.stop(); rec.release(); track.stop(); track.release()
        }.also { it.start() }
    }

    fun stop() { running = false; thread?.join(500); thread = null }
}
