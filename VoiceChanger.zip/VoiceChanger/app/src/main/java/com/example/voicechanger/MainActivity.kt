package com.example.voicechanger

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.widget.*
import java.net.*

class MainActivity : Activity() {
    private val engine = VoiceEngine()
    private val server = ServerEngine()
    private var devices = listOf<AudioDeviceInfo>()
    private lateinit var spinner: Spinner
    private lateinit var toggle: Button
    private lateinit var ip: EditText
    private lateinit var port: EditText
    private var selected = 1
    private var on = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(col)
        col.addView(TextView(this).apply { text = "Смена голоса (лучше в наушниках)"; textSize = 20f })

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        devices = am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            devices.map { "${it.productName} (${it.type})" })
        col.addView(spinner)

        val group = RadioGroup(this)
        val names = listOf("Без эффекта", "Робот", "Высокий голос", "Низкий голос", "Эхо",
            "Годжо (имитация, в телефоне)", "Сукуна (имитация, в телефоне)",
            "Годжо (сервер, настоящий)", "Сукуна (сервер, настоящий)")
        names.forEachIndexed { i, n -> group.addView(RadioButton(this).apply { text = n; id = i + 1 }) }
        group.check(1)
        group.setOnCheckedChangeListener { _, id ->
            selected = id
            if (id <= 7) engine.fx = Fx.values()[id - 1]
        }
        col.addView(group)

        ip = EditText(this).apply { hint = "IP сервера, например 192.168.1.5"; setSingleLine() }
        port = EditText(this).apply { hint = "Порт"; setText("5005"); setSingleLine() }
        ip.setText(getSharedPreferences("vc", 0).getString("ip", ""))
        col.addView(ip); col.addView(port)
        val find = Button(this).apply { text = "Найти сервер автоматически" }
        find.setOnClickListener {
            find.text = "Ищу..."
            Thread {
                var found: String? = null
                try {
                    DatagramSocket().use { s ->
                        s.broadcast = true; s.soTimeout = 2500
                        val msg = "VC?".toByteArray()
                        s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("255.255.255.255"), 5006))
                        val p = DatagramPacket(ByteArray(64), 64)
                        s.receive(p); found = p.address.hostAddress
                    }
                } catch (_: Exception) {}
                val f = found
                runOnUiThread {
                    find.text = "Найти сервер автоматически"
                    if (f != null) { ip.setText(f); Toast.makeText(this, "Найден: $f", Toast.LENGTH_SHORT).show() }
                    else Toast.makeText(this, "Сервер не найден. Запущен ли server.py?", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        col.addView(find)

        toggle = Button(this).apply { text = "Включить микрофон" }
        toggle.setOnClickListener { if (on) stopAll() else ensurePermAndStart() }
        col.addView(toggle)
        setContentView(root)
    }

    private fun ensurePermAndStart() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startAll()
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) startAll()
    }

    private fun startAll() {
        val dev = devices.getOrNull(spinner.selectedItemPosition)
        if (selected <= 7) {
            engine.start(dev)
        } else {
            val voice = if (selected == 8) "gojo" else "sukuna"
            val p = port.text.toString().toIntOrNull() ?: 5005
            getSharedPreferences("vc", 0).edit().putString("ip", ip.text.toString().trim()).apply()
            server.start(dev, ip.text.toString().trim(), p, voice) { msg ->
                runOnUiThread {
                    Toast.makeText(this, "Сервер: $msg", Toast.LENGTH_LONG).show()
                    on = false; toggle.text = "Включить микрофон"
                }
            }
        }
        on = true; toggle.text = "Выключить микрофон"
    }

    private fun stopAll() {
        engine.stop(); server.stop()
        on = false; toggle.text = "Включить микрофон"
    }

    override fun onDestroy() { engine.stop(); server.stop(); super.onDestroy() }
}
