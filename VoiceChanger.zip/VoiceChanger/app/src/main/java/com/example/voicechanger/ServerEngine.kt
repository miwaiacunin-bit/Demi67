package com.example.voicechanger

import android.annotation.SuppressLint
import android.media.*
import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Шлёт микрофон (PCM16, 16 кГц, моно) на сервер и играет то, что вернулось. */
class ServerEngine {
    @Volatile private var running = false
    private var socket: Socket? = null
    private val sr = 16000
    private val chunk = 4096 // сэмплов (256 мс), должно совпадать с CHUNK в server.py

    @SuppressLint("MissingPermission")
    fun start(input: AudioDeviceInfo?, host: String, port: Int, voice: String, onError: (String) -> Unit) {
        if (running) return
        running = true
        Thread {
            var rec: AudioRecord? = null
            var track: AudioTrack? = null
            try {
                val s = Socket(); s.tcpNoDelay = true
                s.connect(InetSocketAddress(host, port), 5000); socket = s
                val out = s.getOutputStream()
                out.write("$voice\n".toByteArray()); out.flush()
                val inp = DataInputStream(s.getInputStream())

                val bytes = chunk * 2
                val minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val r = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, bytes * 2))
                if (input != null) r.preferredDevice = input
                val t = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(sr)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(maxOf(minOut, bytes * 2)).build()
                rec = r; track = t
                r.startRecording(); t.play()

                Thread {
                    val b = ByteArray(bytes)
                    try { while (running) { inp.readFully(b); t.write(b, 0, bytes) } } catch (_: Exception) {}
                }.start()

                val buf = ByteArray(bytes)
                while (running) {
                    var o = 0
                    while (o < bytes && running) {
                        val n = r.read(buf, o, bytes - o)
                        if (n <= 0) break
                        o += n
                    }
                    if (o == bytes) out.write(buf)
                }
            } catch (e: Exception) {
                if (running) onError(e.message ?: "Ошибка соединения")
            } finally {
                running = false
                try { socket?.close() } catch (_: Exception) {}
                try { rec?.stop(); rec?.release() } catch (_: Exception) {}
                try { track?.stop(); track?.release() } catch (_: Exception) {}
            }
        }.start()
    }

    fun stop() { running = false; try { socket?.close() } catch (_: Exception) {} }
}
